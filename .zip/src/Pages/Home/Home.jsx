import React from 'react'
import './home.scss'
import Map from '../../components/Map'
const Home = () => {
  return (
    <>
    <div className="home-parent parent">
        <div className="home-cont cont">
 <Map/>
        </div>
    </div>
      
    </>
  )
}

export default Home
